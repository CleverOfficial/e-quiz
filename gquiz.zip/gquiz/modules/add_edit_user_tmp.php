<?php if(!isset($RUN)) { exit(); } ?>
<script language="JavaScript" type="text/javascript" src="lib/validations.js"></script>
<?php echo $val->DrowJsArrays(); ?>

<form method="post" name="form1">

<table class="desc_text">
    <tr>
        <td width="100px"><?php echo USER_NAME ?> : </td>
        <td><input type="textbox" id="txtName" style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;text-transform: capitalize;" name="txtName" value="<?php echo util::GetData("txtName") ?>" /></td>
    </tr>
    <tr>
        <td><?php echo USER_SURNAME ?> : </td>
        <td><input type="textbox" id="txtSurname" style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;text-transform: capitalize;" name="txtSurname" value="<?php echo util::GetData("txtSurname") ?>" /></td>
    </tr>
    <tr>
        <td><?php echo EMAIL ?> : </td>
        <td><input type="textbox" id="txtEmail" style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;" name="txtEmail" value="<?php echo util::GetData("txtEmail") ?>"  /></td>
    </tr>
    <tr>
        <td><?php echo USER_TYPE ?> : </td>
        <td>
            <select id="drpUserType" style="width:200px;height:30px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;text-transform: capitalize;" name="drpUserType">
                <?php echo $user_type_options ?>
            </select>
        </td>
    </tr>
    <tr>
        <td><?php echo LOGIN ?> : </td>
        <td><input <?php echo $login_disabled ?> type="textbox" id="txtLogin" style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;" name="txtLogin" value="<?php echo util::GetData("txtLogin") ?>" /></td>
    </tr>
     <tr>
        <td><?php echo PASSWORD ?> : </td>
        <td>
            
            <input style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;" style="display:<?php echo $psw_display ?>" type="textbox" id="txtPassword" name="txtPassword" value="<?php echo util::GetData("txtPasswordValue") ?>" />
                
                <label style="display:<?php echo $pswlbl_display ?>" id="lblPsw">******** </label><input type="checkbox" name="chkEdit" id="chkEdit" onclick="ProcessPasswordField()" style="display:<?php echo $pswlbl_display ?>"  /><label style="display:<?php echo $pswlbl_display ?>" for="chkEdit"><?php echo EDIT ?></label>
                
            
        </td>
    </tr>
   <tr>
		<td align=left><?php echo R_ADDRESS ?> : </td>
		<td><input  type=text style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;text-transform: capitalize;" name=txtAddr value="<?php echo util::GetData("txtAddr") ?>" /></td>
	</tr>
	<tr>
		<td align=left><?php echo R_PHONE ?> : </td>
		<td><input  type=text style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);font-weight: bolder;" name=txtPhone value="<?php echo util::GetData("txtPhone") ?>" /> </td>
	</tr>	
<tr>
		<td align=left><?php echo R_APPROVED ?> : </td>
		<td><input type=checkbox style="width:95px;height:20px;color: blue;background-color: #fff;font-weight: bolder;" name=chkApproved <?php echo util::GetData("chkApproved") ?>></td>
	</tr>
<tr>
		<td align=left><?php echo R_DISABLED ?> : </td>
		<td><input type=checkbox style="width:95px;height:20px;color: blue;background-color: #fff;font-weight: bolder;" name=chkDisabled <?php echo util::GetData("chkDisabled") ?> ></td>
	</tr>
    <tr>
        <td><br></td>
    </tr>
    <tr>
        <td colspan="2" align="center">
            <input class="st_button" type="submit" style="width:100px;background-color: green;height: 30px;border-radius: 15px;border-right:0px;border-bottom: 0px;border-left: 0px;border-top: 0px;" name="btnSave" value="<?php echo SAVE ?>" id="btnSave" onclick="return checkform();" />
            <input class="st_button" type="button" style="width:100px;background-color: red;height: 30px;border-radius: 15px;border-right:0px;border-bottom: 0px;border-left: 0px;border-top: 0px;" name="btnCancel" value="<?php echo CANCEL ?>" id="btnCancel" onclick="javascript:window.location.href='?module=local_users'" />
        </td>
    </tr>
</table>
    <input type="hidden" id="hdnMode" value="<?php echo $mode ?>">
</form>
<script language="javascript">
function ProcessPasswordField()
{
    var checked = document.getElementById('chkEdit').checked ;
    if(checked)
    {
        document.getElementById('txtPassword').style.display="";
        document.getElementById('txtPassword').value="";
        document.getElementById('lblPsw').style.display="none";
    }
    else
    {
        document.getElementById('txtPassword').style.display="none";
        document.getElementById('txtPassword').value="********";
        document.getElementById('lblPsw').style.display="";
    }
}

function checkform()
{
    var mode = document.getElementById('hdnMode').value;

    if(mode=="edit")
    {
        return validate();
    }
    else
    {
        var user_name= document.getElementById('txtLogin').value
        var status=validate();
        if(status)
        {
             $.post("?module=add_edit_user", { login_to_check: user_name, ajax: "yes" },
             function(data){
                 if(data=="0")
                 {
                     return true;
                 }
                 else
                 {
                    alert('<?php echo LOGIN_ALREADY_EXISTS ?>');
                    return false;
                 }

            });
        }
        else
        {
            return false;
        }
    }
}
</script>
