<?php if(!isset($RUN)) { exit(); } ?>

<div style="width:700px">
<?php echo $page_content;  ?>
</div>
