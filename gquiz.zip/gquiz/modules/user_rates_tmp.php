<?php

echo $grid_html;

?>

<br>
<a href="?module=ratings"><?php echo BACK_TO_RAT ?></a>
