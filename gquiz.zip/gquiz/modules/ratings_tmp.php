<?php if(!isset($RUN)) { exit(); } ?>
<div id="div_grid"><?php echo $grid_html ?></div>
    <br>
    <hr />

    <a href="?module=add_edit_rating"><?php echo NEW_RAT ?></a>
    <br>
    <br>