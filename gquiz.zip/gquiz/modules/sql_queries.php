<?php if(!isset($RUN)) { exit(); } ?>
<?php

access::allow("1");

function desc_func() { return  SQL_QUERIES; }

?>
