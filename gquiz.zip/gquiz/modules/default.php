<?php if(!isset($RUN)) { exit(); } ?>

<?php

function desc_func()
    {
        return "Main page";
    }

?>