<?php if(!isset($RUN)) { exit(); } ?>
<script language="JavaScript" type="text/javascript" src="lib/validations.js"></script>
<?php echo $val->DrowJsArrays(); ?>
<script language="javascript">

function checkform()
{
	document.form1.btnSave.disabled=true;
	var old_pass= document.getElementById('txtOldPass').value;
	var new_pass= document.getElementById('txtNewPass').value;
        var status=validate();
        if(status)
        {
             $.post("?module=change_password", { old_password: old_pass, new_password : new_pass, ajax: "yes" },
             function(data){
                    alert(data);
                    document.form1.btnSave.disabled=false;                
            });
        }
        else
        {
            document.form1.btnSave.disabled=false;
        } 
}
</script>
<form id=form1 name=form1>
<table style="display:<?php echo $pass_display ?>">
	<tr>
		<td class="desc_text">
			<?php echo OLD_PASS ?> : 
		</td>
		<td>
			<input type="txtOldPass" id=txtOldPass name=txtOldPass style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);" maxlength=20  />  
		</td>
	</tr>
	<tr>
		<td class="desc_text">
			<?php echo NEW_PASS ?> : 
		</td>
		<td>
			<input type="txtOldPass" id=txtNewPass name=txtNewPass style="width:195px;height:20px;color: blue;padding: 1px 0px 1px;background-color: #fff;border: 3px groove rgba(0,0,0,0.1);" maxlength=20  /> 
		</td>
	</tr>
	<tr>
		<td colspan=2 align=center><br><br>
			<input type=button id=btnSave style="width:100px;background-color: green;height: 30px;border-radius: 15px;border-right:0px;border-bottom: 0px;border-left: 0px;border-top: 0px;" name=btnSave value="<?php echo SAVE ?>" onclick="checkform()" style="width:125px" />
			<input type=button id=btnCancel style="width:100px;background-color: red;height: 30px;border-radius: 15px;border-right:0px;border-bottom: 0px;border-left: 0px;border-top: 0px;" name=btnCancel value="<?php echo CANCEL ?>" onclick="javascript:history.back(1)" style="width:125px" />
		</td>	
	</tr>
</table>

<table style="display:<?php echo $msg_display ?>">
	<tr>
		<td class="desc_text">
			<?php echo ONLY_LOCAL ?>  
		</td>
</table>
</form>
