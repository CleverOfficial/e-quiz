<?php if(!isset($RUN)) { exit(); } ?>
<div id="div_grid"><?php echo $grid_html ?></div>
<br>
    <hr />
<a href="?module=add_page"><?php echo ADD_PAGE ?></a>
