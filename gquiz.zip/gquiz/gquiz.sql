-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2018 at 10:40 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gquiz`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `move_question` (`v_direction` VARCHAR(4), `v_question_id` INT)  BEGIN
declare id_up int;
declare priority_up int;
declare id_down int     ;
declare priority_down int;
declare priority_current int;
declare v_quiz_id int;
select priority,quiz_id into priority_current,v_quiz_id from questions where id=v_question_id and parent_id=0;
select id,priority into id_up,priority_up from questions where quiz_id=v_quiz_id and priority<priority_current and parent_id=0 order by priority desc limit 0,1;
select id,priority into id_down,priority_down from questions where quiz_id=v_quiz_id and priority>priority_current and parent_id=0 order by priority limit 0,1;
if v_direction = 'up' then
    if priority_up is not null then
update questions set priority=priority_up where id=v_question_id and parent_id=0;
update questions set priority=priority_current where id=id_up and parent_id=0;
    end if;
ELSEIF  v_direction = 'down' then
    if priority_down is not null then
update questions set priority=priority_down where id=v_question_id and parent_id=0;
update questions set priority=priority_current where id=id_down and parent_id=0;
    end if;
end if ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `p_quiz_results` (`v_user_quiz_id` INT)  begin

select total_point,
	   total_perc,
	   user_quiz_id,
	   results_mode,
	   show_results,
	   pass_score,
	   (case results_mode when 1 then ( case when total_point >= pass_score then 1 else 0 end) 
						 when 2 then ( case when total_perc >= pass_score then 1 else 0 end) end ) as quiz_success
	   from (
select ifnull(round(sum((case when q_total < 0 then 0 else q_total end)),2),0) as total_point ,
	   ifnull(round(sum((case when q_perc < 0 then 0 else q_perc end)),2),0) as total_perc ,
	   uqz.id as user_quiz_id,
	   asg.results_mode,
	   asg.show_results,
	   asg.pass_score
from user_quizzes uqz
left join (
select SUM(correct_answers_count) ca_total, 
	   COUNT(*) a_count,
	   question_id,
	   point ,	     
	   (point / (case when question_type_id in (0,1) then (case ca_count when 0 then 1 else ca_count end) else answer_count end ) ) * SUM(correct_answers_count) as q_total,
	   qst.answer_count,
	   question_type_id,
	   ca_count,
	   user_quiz_id,
	   ((100.00/cnts.q_count)/(case when question_type_id in (0,1) then (case ca_count when 0 then 1 else ca_count end) else answer_count end ) ) * SUM(correct_answers_count) as q_perc
	   from (
select (
			case when q.question_type_id in (0,1) then
				case when a.correct_answer=1 then
					1
				else -1 end
				when q.question_type_id in (3,4) then
				case when uq.user_answer_text = a.correct_answer_text then
					1
				else -1 end
			end
		) correct_answers_count ,
		q.point,
		uq.question_id,	
		q.question_type_id,
		q.quiz_id,
		uq.user_quiz_id 
from user_answers uq
left join answers a on a.id = uq.answer_id
left join questions q on q.id = uq.question_id

) total 
left join (

				select count(*) answer_count, SUM(correct_answer) ca_count , qs.id from answers av
				left join question_groups qg on qg.id = av.group_id
			    left join questions qs on qs.id=qg.question_id
			    where av.control_type=1

			    group by qs.id
	
			) qst
on qst.id = total.question_id
left join (
				select COUNT(*) q_count,quiz_id from questions 				

			    group by quiz_id 
			)	cnts on cnts.quiz_id = total.quiz_id
group by question_id ,
		 qst.answer_count,
		 cnts.q_count,
		 point ,question_type_id ,qst.ca_count,
		 user_quiz_id
) results 
on uqz.id=results.user_quiz_id
left join assignments asg on asg.id = uqz.assignment_id
where user_quiz_id=v_user_quiz_id
group by user_quiz_id,
		 asg.results_mode,
		  uqz.id,
	   asg.results_mode,
	   asg.show_results,
	   asg.pass_score
	   ) res ;
	   
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `answer_text` varchar(800) DEFAULT NULL,
  `answer_image` varchar(450) DEFAULT NULL,
  `correct_answer` int(11) NOT NULL,
  `priority` int(11) DEFAULT NULL,
  `correct_answer_text` varchar(800) DEFAULT NULL,
  `answer_pos` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL,
  `answer_text_eng` varchar(800) DEFAULT NULL,
  `control_type` int(11) DEFAULT NULL,
  `answer_parent_id` int(11) DEFAULT NULL,
  `text_unit` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `group_id`, `answer_text`, `answer_image`, `correct_answer`, `priority`, `correct_answer_text`, `answer_pos`, `parent_id`, `answer_text_eng`, `control_type`, `answer_parent_id`, `text_unit`) VALUES
(1, 1, 'Dn. Ayo Oyebanji', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(2, 1, 'Coun. Pastor F.A.S Akinola', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(3, 1, 'Coun. Dr. Hon. Dawari George', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(4, 1, 'Dn. J.O Oyeku', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(5, 2, '3', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(6, 2, '4', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(7, 2, '5', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(8, 2, '6', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(14, 5, 'Coun. Dauda Daniel', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(15, 5, 'Coun. Harry Ogbomo', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(16, 5, 'Coun. Adisa O. Buxton', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(17, 5, 'Coun. Egbebi Emmanuel', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(18, 6, '', NULL, 0, 0, '2000', 1, 0, NULL, 1, 0, ''),
(24, 8, 'Reied W. Orveil', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(25, 8, 'Orvil W. Reid', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(26, 8, 'Harold D. Wicks', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(27, 8, 'Harold D. Lasswell', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(28, 9, '', NULL, 0, 0, 'All African Baptist Men\'s Fellowship', 1, 0, NULL, 1, 0, ''),
(29, 10, '3', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(30, 10, '4', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(31, 10, '5', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(32, 10, '6', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(33, 11, 'Special Intern and Envoy', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(34, 11, 'Special Intern and Special Envoy', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(35, 11, 'Assistant Intern and Special Envoy', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(36, 11, 'Senior Intern and Dean', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(37, 12, 'Senior Board Chairman, Vice Chancellor', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(38, 12, 'Senior Boarding House Chairman, Village Outreach Committee', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(39, 12, 'Southern Baptist Chairperson, Vices Commission', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(40, 12, 'Southern Baptist Convention, Volunteer Counselor', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(41, 13, 'Orvil W. Reid', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(42, 13, 'E.T Cassel', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(43, 13, 'Harold D. Wicks', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(44, 13, 'Harry Ogbomo', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(45, 14, 'Harold D. Wicks', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(46, 14, 'Orvil W. Reid', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(47, 14, 'E.T Cassel', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(48, 14, 'James Smith', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(53, 16, 'about ambassador, devil, happiness', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(54, 16, 'about Christ, world, dance', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(55, 16, 'about Ayo Adekunle, RAN, Family', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(56, 16, 'is the worth of a boy, sorrow, service', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(61, 18, '19', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(62, 18, '20', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(63, 18, '21', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(64, 18, '22', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(65, 19, 'far away upon, shrine', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(66, 19, 'brighter far, strand', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(67, 19, 'far away upon, strand', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(68, 19, 'far array upon, strand', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(69, 20, '2', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(70, 20, '3', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(71, 20, '4', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(72, 20, 'None of the above', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(73, 21, 'Boys and Women Academy', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(74, 21, 'Baptist World Alliance', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(75, 21, 'Baptist Women Wing', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(76, 21, 'Baptist Women Wing', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(77, 22, 'Coun. Biodun Eegundiran', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(78, 22, 'Coun. Pastor F.A.S Akinola', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(79, 22, 'Coun. Ayo Adekunle', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(80, 22, 'Hon. Dr. Dawari George', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(81, 23, 'Provost', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(82, 23, 'Special duties officer', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(83, 23, 'Song leader', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(84, 23, 'Dean', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(85, 24, '', NULL, 0, 0, 'Dean', 1, 0, NULL, 1, 0, ''),
(91, 26, 'Rev. Dr. Harold D. Wicks', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(92, 26, 'Rev. Dr. Samson O. Olaniyan', NULL, 1, 0, '', 1, 0, NULL, 1, 0, ''),
(93, 26, 'Rev. Olubusayo Oladejo', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(94, 26, 'Mr. Ayo Badejo', NULL, 0, 0, '', 1, 0, NULL, 1, 0, ''),
(95, 26, 'Revd Dr. Olubamiji Alade', NULL, 0, 0, '', 1, 0, NULL, 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL DEFAULT '0',
  `org_quiz_id` int(11) NOT NULL DEFAULT '0',
  `results_mode` int(11) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `quiz_time` int(11) NOT NULL DEFAULT '0',
  `show_results` int(11) NOT NULL DEFAULT '0',
  `pass_score` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quiz_type` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `allow_review` int(11) NOT NULL DEFAULT '2',
  `qst_order` int(11) NOT NULL DEFAULT '1',
  `answer_order` int(11) NOT NULL DEFAULT '1',
  `affect_changes` int(11) NOT NULL,
  `limited` int(11) NOT NULL,
  `send_results` int(11) NOT NULL,
  `accept_new_users` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `quiz_id`, `org_quiz_id`, `results_mode`, `added_date`, `quiz_time`, `show_results`, `pass_score`, `quiz_type`, `status`, `allow_review`, `qst_order`, `answer_order`, `affect_changes`, `limited`, `send_results`, `accept_new_users`) VALUES
(1, 107, 107, 2, '2018-08-11 00:34:29', 5, 1, '55.00', 1, 1, 2, 2, 2, 2, 1, 2, 2),
(2, 107, 107, 2, '2018-08-12 21:11:54', 5, 1, '60.00', 1, 1, 1, 2, 2, 2, 1, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `assignment_users`
--

CREATE TABLE `assignment_users` (
  `id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL DEFAULT '0',
  `user_type` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assignment_users`
--

INSERT INTO `assignment_users` (`id`, `assignment_id`, `user_type`, `user_id`) VALUES
(1, 1, 1, 50008),
(2, 1, 1, 50006),
(3, 1, 1, 50005),
(4, 2, 1, 50011),
(5, 2, 1, 50009),
(6, 2, 1, 50008),
(7, 2, 1, 50006),
(8, 2, 1, 50005);

-- --------------------------------------------------------

--
-- Table structure for table `cats`
--

CREATE TABLE `cats` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cats`
--

INSERT INTO `cats` (`id`, `cat_name`) VALUES
(62, 'ENVOY'),
(63, 'SENIOR ENVOY'),
(64, 'SPECIAL ENVOY'),
(65, 'DEAN'),
(68, 'AMBASSADOR');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `vars` varchar(300) DEFAULT NULL,
  `body` text,
  `subject` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `name`, `vars`, `body`, `subject`) VALUES
(1, 'register_user', '[UserName],[Name],[Surname],[email], [address], [phone], [url]', 'Dear [Name] [Surname] , \n\nYou have registered in our system . Here is the details of registration\n\nName : [Name] \nSurname  : [Surname]\nLogin : [UserName]\nAddress : [address]\nPhone : [phone]\nEmail : [email]\n\nTo approve your registration in our Quiz system , please open below link \n\n[url]\n\nThanks', 'Registration in Quiz System'),
(2, 'forgot_password', '[UserName],[Name],[Surname],[email],[address],[phone],[url],[random_password]', 'Dear [Name] [Surname] ,\n\nYou password has been reseted , please find your password below .\n\nLogin : [UserName]\nPassword : [random_password]\nEmail : [email]\n\nThanks', 'Restoring the password'),
(3, 'quiz_start_message', '[UserName],[Name],[Surname],[email],[address], [phone],[url],[quiz_name]', 'Dear [Name] [Surname] , \n\nThe below listed exam has been started . \n\nQuiz name : [quiz_name]\nName : [Name] \nSurname  : [Surname]\nLogin : [UserName]\n\nTo join to exam please , use below link\n\n[url]\n\nThanks', 'Online exam started'),
(4, 'quiz_results_success', '[UserName],[Name],[Surname],[email],[url],[quiz_name],[start_date],[finish_date],[pass_score],[user_score]', 'Dear [Name] [Surname] ,\n\nYou passed exam successfully . \n\nQuiz name : [quiz_name]\nStart date : [start_date]\nFinish date : [finish_date]\nPass score : [pass_score]\nYour score : [user_score]\n\nThanks,\nAdministrator', 'You passed exam succesfully'),
(5, 'quiz_results_not_success', '[UserName],[Name],[Surname],[email],[url],[quiz_name],[start_date],[finish_date],[pass_score],[user_score]', 'Dear [Name] [Surname] ,\n\nSorry , you didn\'t pass exam succesfully . \n\nQuiz name : [quiz_name]\nStart date : [start_date]\nFinish date : [finish_date]\nPass score : [pass_score]\nYour score : [user_score]\n\nThanks,\nAdministrator', 'Sorry , you didn\'t pass exam succesfully');

-- --------------------------------------------------------

--
-- Table structure for table `imported_users`
--

CREATE TABLE `imported_users` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL DEFAULT '',
  `surname` varchar(255) NOT NULL DEFAULT '',
  `user_name` varchar(150) NOT NULL DEFAULT '',
  `password` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `module_name` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `priority` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `module_name`, `file_name`, `parent_id`, `priority`) VALUES
(1, 'Quizzes', NULL, 0, 1),
(2, 'Categories', 'cats', 1, 1),
(3, 'Quizzes', 'quizzes', 1, 2),
(4, 'Local users', 'local_users', 13, 4),
(5, 'Assignments', NULL, 0, 2),
(6, 'Assignments', 'assignments', 5, 6),
(7, 'New Assignment', 'add_assignment', 5, 7),
(8, 'Assignments', NULL, 0, 3),
(9, 'Active Assignments', 'active_assignments', 8, 1),
(10, 'My old assigments', 'old_assignments', 8, 2),
(11, 'New User', 'add_edit_user', 13, 7),
(12, 'New Quiz', 'add_edit_quiz', 1, 3),
(13, 'Users', '', 0, 4),
(17, 'Ratings', '', 0, 5),
(18, 'Ratings', 'ratings', 17, 1),
(19, 'Add rating', 'add_edit_rating', 17, 2),
(20, 'Change password', 'change_password', 13, 10),
(21, 'Settings', NULL, 0, 6),
(23, 'Content management', 'cms', 21, 1),
(24, 'SQL Queries', 'sql_queries', 21, 2),
(26, 'Imported users', 'imported_users', 13, 5);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `page_name` varchar(800) NOT NULL,
  `page_content` text NOT NULL,
  `priority` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `page_name`, `page_content`, `priority`) VALUES
(1, 'Home', '', 0),
(2, 'About', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment_orders`
--

CREATE TABLE `payment_orders` (
  `order_id` int(11) NOT NULL,
  `txn_id` varchar(19) NOT NULL,
  `payer_email` varchar(75) NOT NULL,
  `mc_gross` decimal(18,4) NOT NULL,
  `inserted_date` datetime NOT NULL,
  `currency` varchar(10) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB AVG_ROW_LENGTH=1820 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question_text` varchar(3800) DEFAULT NULL,
  `question_type_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `point` decimal(18,0) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `parent_id` int(11) NOT NULL,
  `question_total` decimal(18,0) DEFAULT NULL,
  `check_total` int(11) DEFAULT NULL,
  `header_text` varchar(1500) DEFAULT NULL,
  `footer_text` varchar(1500) DEFAULT NULL,
  `question_text_eng` varchar(1800) DEFAULT NULL,
  `help_image` varchar(550) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_text`, `question_type_id`, `priority`, `quiz_id`, `point`, `added_date`, `parent_id`, `question_total`, `check_total`, `header_text`, `footer_text`, `question_text_eng`, `help_image`) VALUES
(1, '<p>\r\n	<u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u> is the 3rd marshal in the history of the Royal Ambassadors of Nigeria.</p>', 1, 1, 107, '2', '2018-08-10 13:49:07', 0, NULL, NULL, '', '', NULL, NULL),
(2, '<p>\r\n	The National R.A Jamboree is a programme that comes up once every&nbsp;<u> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </u>&nbsp;years.</p>', 1, 2, 107, '2', '2018-08-10 13:50:41', 0, NULL, NULL, '', '', NULL, NULL),
(3, '<p>\r\n	The Anti-Social vices club of the Royal Ambassadors of Nigeria was envisioned in the year &nbsp; &nbsp;<u> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</u>.</p>', 3, 3, 107, '3', '2018-08-10 13:52:15', 0, NULL, NULL, '', '', NULL, NULL),
(4, '<p>\r\n	<u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u>is the editorial chairman of the Royal Ambassador of Nigeria.</p>', 1, 4, 107, '2', '2018-08-10 13:53:55', 0, NULL, NULL, '', '', NULL, NULL),
(5, '<p>\r\n	<u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u> is the pioneer Director of Men and Boys Department of Nigerian Baptist Convention.</p>', 1, 5, 107, '2', '2018-08-10 22:06:58', 0, NULL, NULL, '', '', NULL, NULL),
(6, '<p>\r\n	According to the RA Manual, Who wrote the Worth of a Boy?</p>', 1, 6, 107, '2', '2018-08-10 22:08:35', 0, NULL, NULL, '', '', NULL, NULL),
(7, '<p>\r\n	AABMF means &nbsp;<u> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</u></p>', 3, 7, 107, '3', '2018-08-10 22:09:55', 0, NULL, NULL, '', '', NULL, NULL),
(8, '<p>\r\n	The Royal Ambassadors of Nigeria has <u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u> founding goals.</p>', 1, 8, 107, '2', '2018-08-10 22:11:05', 0, NULL, NULL, '', '', NULL, NULL),
(9, '<p>\r\n	What rank is before Intern and Senior Envoy?</p>', 1, 9, 107, '2', '2018-08-10 22:12:59', 0, NULL, NULL, '', '', NULL, NULL),
(10, '<p>\r\n	What is the full meaning of SBC and VC?</p>', 1, 10, 107, '2', '2018-08-10 22:14:18', 0, NULL, NULL, '', '', NULL, NULL),
(11, '<p>\r\n	Who wrote the King&rsquo;s Business?</p>', 1, 11, 107, '1', '2018-08-10 22:15:24', 0, NULL, NULL, '', '', NULL, NULL),
(12, '<p>\r\n	<u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u> prepared the R.A Manual.</p>', 1, 12, 107, '2', '2018-08-10 22:16:43', 0, NULL, NULL, '', '', NULL, NULL),
(13, '<p>\r\n	What would you say <u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</u> in sin and <u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </u>, in&nbsp;<u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u>&nbsp;and joy.</p>', 1, 13, 107, '3', '2018-08-10 22:19:21', 0, NULL, NULL, 'Complete the below sentence:', '', NULL, NULL),
(14, '<p>\r\n	How many associations do we have in Ogbomoso Baptist Conference?</p>', 1, 14, 107, '2', '2018-08-10 22:21:35', 0, NULL, NULL, '', '', NULL, NULL),
(15, '<p>\r\n	My home is <u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </u>&nbsp;a golden <u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</u>&nbsp;.</p>', 1, 15, 107, '2', '2018-08-10 22:23:47', 0, NULL, NULL, '', '', NULL, NULL),
(16, '<p>\r\n	How many colour has the Royal Ambassador emblem?</p>', 1, 16, 107, '1', '2018-08-10 22:24:51', 0, NULL, NULL, '', '', NULL, NULL),
(17, '<p>\r\n	BWA means <u>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</u></p>', 1, 17, 107, '2', '2018-08-10 22:26:40', 0, NULL, NULL, '', '', NULL, NULL),
(18, '<p>\r\n	who wrote the Forward of the 2017 Christ Ambassador?</p>', 1, 18, 107, '2', '2018-08-10 22:27:52', 0, NULL, NULL, '', '', NULL, NULL),
(19, '<div>\r\n	The following are chapter officers as written in the manual <em>EXCEPT</em></div>\r\n<div>\r\n	&nbsp;</div>', 1, 19, 107, '2', '2018-08-10 22:29:44', 0, NULL, NULL, '', '', NULL, NULL),
(20, '<p>\r\n	Which rank is after Senior envoy?</p>', 3, 20, 107, '3', '2018-08-10 22:31:37', 0, NULL, NULL, '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `question_groups`
--

CREATE TABLE `question_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(450) NOT NULL,
  `show_header` int(11) NOT NULL,
  `group_total` decimal(18,0) NOT NULL,
  `show_footer` int(11) DEFAULT NULL,
  `check_total` decimal(18,0) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `group_name_eng` varchar(450) DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question_groups`
--

INSERT INTO `question_groups` (`id`, `group_name`, `show_header`, `group_total`, `show_footer`, `check_total`, `question_id`, `parent_id`, `group_name_eng`, `added_date`) VALUES
(1, '', 0, '0', NULL, NULL, 1, 0, NULL, '2018-08-10 13:49:07'),
(2, '', 0, '0', NULL, NULL, 2, 0, NULL, '2018-08-10 13:50:41'),
(5, '', 0, '0', NULL, NULL, 4, 0, NULL, '2018-08-10 13:54:13'),
(6, '', 0, '0', NULL, NULL, 3, 0, NULL, '2018-08-10 22:05:01'),
(8, '', 0, '0', NULL, NULL, 6, 0, NULL, '2018-08-10 22:08:36'),
(9, '', 0, '0', NULL, NULL, 7, 0, NULL, '2018-08-10 22:09:55'),
(10, '', 0, '0', NULL, NULL, 8, 0, NULL, '2018-08-10 22:11:06'),
(11, '', 0, '0', NULL, NULL, 9, 0, NULL, '2018-08-10 22:13:00'),
(12, '', 0, '0', NULL, NULL, 10, 0, NULL, '2018-08-10 22:14:18'),
(13, '', 0, '0', NULL, NULL, 11, 0, NULL, '2018-08-10 22:15:24'),
(14, '', 0, '0', NULL, NULL, 12, 0, NULL, '2018-08-10 22:16:43'),
(16, '', 0, '0', NULL, NULL, 13, 0, NULL, '2018-08-10 22:20:23'),
(18, '', 0, '0', NULL, NULL, 14, 0, NULL, '2018-08-10 22:21:51'),
(19, '', 0, '0', NULL, NULL, 15, 0, NULL, '2018-08-10 22:23:48'),
(20, '', 0, '0', NULL, NULL, 16, 0, NULL, '2018-08-10 22:24:51'),
(21, '', 0, '0', NULL, NULL, 17, 0, NULL, '2018-08-10 22:26:41'),
(22, '', 0, '0', NULL, NULL, 18, 0, NULL, '2018-08-10 22:27:52'),
(23, '', 0, '0', NULL, NULL, 19, 0, NULL, '2018-08-10 22:29:45'),
(24, '', 0, '0', NULL, NULL, 20, 0, NULL, '2018-08-10 22:31:37'),
(26, '', 0, '0', NULL, NULL, 5, 0, NULL, '2018-08-11 14:26:16');

-- --------------------------------------------------------

--
-- Table structure for table `question_types`
--

CREATE TABLE `question_types` (
  `id` int(11) NOT NULL,
  `question_type` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question_types`
--

INSERT INTO `question_types` (`id`, `question_type`) VALUES
(0, 'Multi answer (checkbox)'),
(3, 'Free text (textarea)'),
(4, 'Multi text (numbers only)'),
(1, 'One answer (radio button)');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `quiz_name` varchar(500) NOT NULL,
  `quiz_desc` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL,
  `parent_id` int(11) NOT NULL,
  `show_intro` int(11) NOT NULL,
  `intro_text` varchar(3850) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `cat_id`, `quiz_name`, `quiz_desc`, `added_date`, `parent_id`, `show_intro`, `intro_text`) VALUES
(107, 62, '2019 Envoy Ranking Examination', '2019 Envoy Ranking Examination', '2018-08-10 15:45:58', 0, 1, '<h3 style=\"color: blue; text-align: center;\">\r\n	<strong>Make sure you are here for <span style=\"font-size:16px;\"><span style=\"font-family:georgia,serif;\"><em><u><span style=\"background-color:#ffff00;\">ENVOY</span></u></em></span><span style=\"background-color:#ffff00;\"> </span></span>exam. If you&#39;re not, kindly signify and leave the examination hall.&nbsp;</strong></h3>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<br>\r\n<h1 style=\"color: blue; text-align: center;\">\r\n	<span><span style=\"background-color:lime;\"><span style=\"color:#ff0000;\"><span style=\"font-family:georgia,serif;\"><strong style=\"color: rgb(34, 34, 34); font-size: 40px;\">Are &nbsp;you &nbsp;here &nbsp;for &nbsp;</strong></span></span></span><span style=\"color:#ff0000;\"><span style=\"font-family:georgia,serif;\"><strong style=\"color: rgb(34, 34, 34); font-size: 45px;\"><span style=\"background-color:#ffff00;\">ENVOY</span></strong></span></span><span style=\"background-color:lime;\"><span style=\"color:#ff0000;\"><span style=\"font-family:georgia,serif;\"><strong style=\"color: rgb(34, 34, 34); font-size: 40px;\">&nbsp; exam?</strong></span></span></span></span></h1>');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `description` varchar(455) NOT NULL DEFAULT '',
  `temp_id` int(11) NOT NULL DEFAULT '0',
  `header_text` varchar(555) NOT NULL DEFAULT '',
  `footer_text` varchar(555) NOT NULL DEFAULT '',
  `img_count` int(11) NOT NULL DEFAULT '0',
  `show_results` int(11) NOT NULL DEFAULT '0',
  `restrict_user` int(11) NOT NULL DEFAULT '0',
  `bgcolor` varchar(255) NOT NULL DEFAULT '',
  `added_date` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `lang` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `description`, `temp_id`, `header_text`, `footer_text`, `img_count`, `show_results`, `restrict_user`, `bgcolor`, `added_date`, `status`, `lang`) VALUES
(26, 'rating 1', 6, '', '', 5, 1, 1, '-1', '2011-12-20 12:23:00', 1, 'English'),
(31, 'rating 2', 3, '', '', 5, 1, 2, '-1', '2011-12-20 12:23:19', 1, 'English'),
(32, 'rating 3', 2, '', '', 5, 1, 1, '-1', '2011-12-20 12:23:31', 1, 'English');

-- --------------------------------------------------------

--
-- Table structure for table `rating_temps`
--

CREATE TABLE `rating_temps` (
  `id` int(11) NOT NULL,
  `temp_name` varchar(255) NOT NULL DEFAULT '',
  `active_img` varchar(255) NOT NULL DEFAULT '',
  `inactive_img` varchar(255) NOT NULL DEFAULT '',
  `half_active_img` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rating_temps`
--

INSERT INTO `rating_temps` (`id`, `temp_name`, `active_img`, `inactive_img`, `half_active_img`) VALUES
(1, 'Star1', '1.gif', '1_n.gif', '1_h.gif'),
(2, 'Star1', '7.gif', '7_n.gif', '7_h.gif'),
(3, 'Star2', '2.gif', '2_n.gif', '2_h.gif'),
(4, 'Star3', '3.gif', '3_n.gif', '3_h.gif'),
(5, 'Star4', '4.gif', '4_n.gif', '4_h.gif'),
(6, 'Star5', '5.gif', '5_n.gif', '5_h.gif'),
(7, 'Star6', '6.gif', '6_n.gif', '6_h.gif'),
(8, 'Star7', '8.gif', '8_n.gif', '8_h.gif');

-- --------------------------------------------------------

--
-- Table structure for table `roles_rights`
--

CREATE TABLE `roles_rights` (
  `Id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles_rights`
--

INSERT INTO `roles_rights` (`Id`, `role_id`, `module_id`) VALUES
(1, 1, 2),
(2, 1, 3),
(3, 1, 4),
(4, 1, 6),
(5, 1, 7),
(13, 1, 1),
(12, 1, 12),
(11, 1, 11),
(9, 2, 9),
(10, 2, 10),
(14, 1, 5),
(15, 1, 13),
(16, 2, 8),
(17, 1, 17),
(18, 1, 18),
(19, 1, 19),
(20, 1, 20),
(21, 2, 20),
(22, 2, 13),
(23, 1, 21),
(24, 1, 22),
(25, 1, 23),
(26, 1, 24),
(27, 1, 26),
(28, 1, 25);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Surname` varchar(150) NOT NULL,
  `added_date` datetime NOT NULL,
  `user_type` int(11) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `random_str` varchar(100) DEFAULT NULL,
  `approved` int(11) NOT NULL,
  `disabled` int(11) NOT NULL,
  `app_type` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `UserName`, `Password`, `Name`, `Surname`, `added_date`, `user_type`, `email`, `address`, `phone`, `random_str`, `approved`, `disabled`, `app_type`) VALUES
(50001, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin', '2011-10-27 12:02:06', 1, 'elshan999@mail.ru', '', '', NULL, 1, 0, 0),
(50005, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'Akinbami Oluwafemi', 'Popoola', '2018-08-07 20:48:26', 2, 'user', 'user', '9983786734', NULL, 1, 0, 0),
(50006, 'user1', '24c9e15e52afc47c225b757e7bee1f9d', 'Adetoye Oluwatobi', 'Adeoye', '2018-08-07 20:58:45', 2, 'user1', 'user1', '47t835t8t5234', NULL, 1, 0, 0),
(50007, '140000', '44223ca581a65ee010e1194e4c3f339b', 'Akinbami Oluwaseyifunmi', 'Popoola', '2018-08-08 14:13:49', 1, 'akin', 'ogbomoso', '08136509820', NULL, 1, 0, 0),
(50008, 'user2', '7e58d63b60197ceb55a1c487989a3720', 'Oluwaseun Ayodeji', 'Aremu', '2018-08-11 00:33:13', 2, 'user2', 'user2', '7843734', NULL, 1, 0, 0),
(50009, 'user3', '92877af70a45fd6a2ed7fe81e1236b78', 'Babatunde Paulinho', 'Olapade', '2018-08-11 00:33:51', 2, 'user3', 'user3', '08136509820', NULL, 1, 0, 0),
(50010, '140034', '33275e5ed0facfe183af9bc640d5a8ac', 'Akinbami Oluwaseyifunmi', 'Popoola', '2018-08-12 00:53:11', 1, 'akinbamiPopoola@gmail.com', 'ogbomoso', '08160342288', NULL, 1, 0, 0),
(50011, '140001', '8977c4746fef0149df6eb19886b83a11', 'adewale sunday', 'popoola', '2018-08-12 15:50:46', 2, 'ade', 'ade', '07038247776', NULL, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_answers`
--

CREATE TABLE `user_answers` (
  `id` int(11) NOT NULL,
  `user_quiz_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer_id` int(11) DEFAULT NULL,
  `user_answer_id` int(11) DEFAULT NULL,
  `user_answer_text` varchar(3800) DEFAULT NULL,
  `added_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_answers`
--

INSERT INTO `user_answers` (`id`, `user_quiz_id`, `question_id`, `answer_id`, `user_answer_id`, `user_answer_text`, `added_date`) VALUES
(234, 55, 389, 176236, 176236, NULL, '2018-08-07 20:50:01'),
(235, 57, 389, 176235, 176235, NULL, '2018-08-10 01:16:25'),
(236, 58, 390, 176248, 176248, NULL, '2018-08-10 01:42:34'),
(238, 58, 389, 176256, 176256, NULL, '2018-08-10 01:42:47'),
(239, 58, 391, 176252, 176252, NULL, '2018-08-10 01:42:54'),
(240, 59, 391, 176251, 176251, NULL, '2018-08-10 01:43:26'),
(241, 59, 390, 176246, 176246, NULL, '2018-08-10 01:43:34'),
(242, 59, 389, 176255, 176255, NULL, '2018-08-10 01:44:10'),
(244, 60, 2, 6, 6, NULL, '2018-08-10 15:57:17'),
(245, 60, 4, 14, 14, NULL, '2018-08-10 15:57:25'),
(246, 60, 1, 3, 3, NULL, '2018-08-10 15:57:32'),
(247, 60, 3, 9, NULL, '2000', '2018-08-10 15:57:42'),
(248, 61, 4, 16, 16, NULL, '2018-08-10 15:58:17'),
(249, 61, 3, 9, NULL, '2000', '2018-08-10 15:58:22'),
(250, 61, 2, 7, 7, NULL, '2018-08-10 15:58:25'),
(251, 61, 1, 2, 2, NULL, '2018-08-10 15:58:31'),
(252, 1, 12, 45, 45, NULL, '2018-08-11 00:36:39'),
(253, 1, 5, 20, 20, NULL, '2018-08-11 00:36:46'),
(254, 1, 11, 42, 42, NULL, '2018-08-11 00:36:53'),
(255, 1, 18, 79, 79, NULL, '2018-08-11 00:36:59'),
(256, 1, 19, 84, 84, NULL, '2018-08-11 00:37:04'),
(257, 1, 8, 31, 31, NULL, '2018-08-11 00:37:09'),
(258, 1, 9, 35, 35, NULL, '2018-08-11 00:37:18'),
(259, 1, 20, 85, NULL, 'Dean', '2018-08-11 00:37:28'),
(260, 1, 2, 6, 6, NULL, '2018-08-11 00:37:33'),
(261, 1, 4, 16, 16, NULL, '2018-08-11 00:37:39'),
(262, 1, 10, 40, 40, NULL, '2018-08-11 00:37:53'),
(263, 1, 17, 74, 74, NULL, '2018-08-11 00:38:00'),
(264, 1, 7, 28, NULL, 'All Aliance forum', '2018-08-11 00:38:16'),
(265, 1, 15, 67, 67, NULL, '2018-08-11 00:38:27'),
(266, 1, 3, 18, NULL, '2000', '2018-08-11 00:38:32'),
(267, 1, 13, 56, 56, NULL, '2018-08-11 00:38:38'),
(268, 1, 14, 61, 61, NULL, '2018-08-11 00:38:44'),
(269, 1, 16, 71, 71, NULL, '2018-08-11 00:38:48'),
(270, 1, 6, 25, 25, NULL, '2018-08-11 00:39:21'),
(271, 2, 5, 20, 20, NULL, '2018-08-11 00:57:41'),
(272, 2, 19, 84, 84, NULL, '2018-08-11 00:57:44'),
(273, 2, 10, 40, 40, NULL, '2018-08-11 00:57:49'),
(274, 2, 2, 6, 6, NULL, '2018-08-11 00:57:56'),
(275, 2, 3, 18, NULL, '', '2018-08-11 00:57:57'),
(276, 2, 1, 4, 4, NULL, '2018-08-11 00:58:01'),
(277, 2, 11, 43, 43, NULL, '2018-08-11 00:58:06'),
(278, 2, 17, 74, 74, NULL, '2018-08-11 00:58:09'),
(279, 2, 13, 54, 54, NULL, '2018-08-11 00:58:12'),
(280, 2, 12, 45, 45, NULL, '2018-08-11 00:58:18'),
(281, 2, 7, 28, NULL, '', '2018-08-11 00:58:20'),
(282, 2, 20, 85, NULL, 'dean', '2018-08-11 00:58:33'),
(283, 2, 8, 31, 31, NULL, '2018-08-11 00:58:38'),
(284, 2, 6, 27, 27, NULL, '2018-08-11 00:58:43'),
(285, 2, 4, 16, 16, NULL, '2018-08-11 00:58:48'),
(286, 2, 16, 70, 70, NULL, '2018-08-11 00:58:53'),
(287, 2, 9, 34, 34, NULL, '2018-08-11 00:59:01'),
(288, 2, 14, 61, 61, NULL, '2018-08-11 00:59:08'),
(289, 2, 15, 66, 66, NULL, '2018-08-11 00:59:13'),
(290, 2, 18, 79, 79, NULL, '2018-08-11 00:59:23'),
(292, 3, 8, 31, 31, NULL, '2018-08-11 01:07:18'),
(293, 3, 15, 67, 67, NULL, '2018-08-11 01:07:24'),
(294, 3, 10, 40, 40, NULL, '2018-08-11 01:07:30'),
(295, 3, 20, 85, NULL, 'Dean', '2018-08-11 01:07:35'),
(296, 3, 17, 74, 74, NULL, '2018-08-11 01:07:41'),
(297, 3, 6, 25, 25, NULL, '2018-08-11 01:07:45'),
(298, 3, 11, 42, 42, NULL, '2018-08-11 01:07:52'),
(299, 3, 4, 14, 14, NULL, '2018-08-11 01:07:57'),
(300, 3, 3, 18, NULL, '200', '2018-08-11 01:08:04'),
(301, 3, 5, 19, 19, NULL, '2018-08-11 01:08:34'),
(302, 3, 18, 79, 79, NULL, '2018-08-11 01:08:42'),
(303, 3, 9, 35, 35, NULL, '2018-08-11 01:09:04'),
(304, 3, 19, 82, 82, NULL, '2018-08-11 01:09:10'),
(305, 4, 20, 85, NULL, 'Dean', '2018-08-12 21:17:22'),
(306, 4, 17, 74, 74, NULL, '2018-08-12 21:17:31'),
(307, 5, 12, 45, 45, NULL, '2018-08-12 21:18:00'),
(308, 5, 5, 92, 92, NULL, '2018-08-12 21:18:12'),
(309, 5, 11, 42, 42, NULL, '2018-08-12 21:18:23'),
(310, 5, 18, 79, 79, NULL, '2018-08-12 21:18:32'),
(311, 5, 19, 84, 84, NULL, '2018-08-12 21:18:39'),
(312, 5, 8, 31, 31, NULL, '2018-08-12 21:18:44'),
(313, 5, 9, 35, 35, NULL, '2018-08-12 21:18:58'),
(314, 5, 20, 85, NULL, 'Dean', '2018-08-12 21:19:16'),
(315, 5, 2, 6, 6, NULL, '2018-08-12 21:19:22'),
(316, 5, 4, 16, 16, NULL, '2018-08-12 21:19:35'),
(318, 6, 9, 35, 35, NULL, '2018-08-15 10:48:44'),
(319, 6, 17, 74, 74, NULL, '2018-08-15 10:48:51'),
(320, 6, 18, 79, 79, NULL, '2018-08-15 10:48:56'),
(321, 6, 15, 67, 67, NULL, '2018-08-15 10:49:02'),
(322, 6, 5, 92, 92, NULL, '2018-08-15 10:49:09'),
(323, 6, 20, 85, NULL, 'Dean', '2018-08-15 10:49:15'),
(324, 6, 19, 84, 84, NULL, '2018-08-15 10:49:19'),
(325, 6, 12, 45, 45, NULL, '2018-08-15 10:49:27'),
(327, 6, 13, 56, 56, NULL, '2018-08-15 10:49:37'),
(328, 6, 2, 6, 6, NULL, '2018-08-15 10:49:41'),
(329, 6, 11, 42, 42, NULL, '2018-08-15 10:49:45'),
(330, 6, 4, 16, 16, NULL, '2018-08-15 10:49:54'),
(331, 6, 8, 31, 31, NULL, '2018-08-15 10:49:58'),
(332, 6, 1, 2, 2, NULL, '2018-08-15 10:50:14'),
(333, 6, 10, 40, 40, NULL, '2018-08-15 10:50:21'),
(334, 6, 3, 18, NULL, '1990', '2018-08-15 10:50:31'),
(335, 6, 16, 71, 71, NULL, '2018-08-15 10:50:36'),
(336, 6, 7, 28, NULL, '', '2018-08-15 10:50:42'),
(337, 6, 14, 61, 61, NULL, '2018-08-15 10:50:47');

-- --------------------------------------------------------

--
-- Table structure for table `user_quizzes`
--

CREATE TABLE `user_quizzes` (
  `id` int(11) NOT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `added_date` datetime DEFAULT NULL,
  `success` int(11) DEFAULT NULL,
  `finish_date` datetime DEFAULT NULL,
  `pass_score_point` decimal(10,2) DEFAULT NULL,
  `pass_score_perc` decimal(10,2) DEFAULT NULL,
  `archived` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_quizzes`
--

INSERT INTO `user_quizzes` (`id`, `assignment_id`, `user_id`, `status`, `added_date`, `success`, `finish_date`, `pass_score_point`, `pass_score_perc`, `archived`) VALUES
(1, 1, 50005, 2, '2018-08-11 00:36:30', 1, '2018-08-11 00:39:21', '35.00', '85.00', 0),
(2, 1, 50008, 2, '2018-08-11 00:57:36', 0, '2018-08-11 00:59:24', '21.00', '50.00', 0),
(3, 1, 50006, 3, '2018-08-11 01:04:17', 0, '2018-08-11 01:09:25', '18.00', '45.00', 0),
(4, 2, 50006, 3, '2018-08-12 21:14:23', 0, '2018-08-12 21:19:51', '5.00', '10.00', 0),
(5, 2, 50005, 3, '2018-08-12 21:15:07', 0, '2018-08-12 21:22:05', '20.00', '50.00', 0),
(6, 2, 50009, 3, '2018-08-15 10:46:11', 1, '2018-08-15 10:51:20', '30.00', '75.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_ratings`
--

CREATE TABLE `user_ratings` (
  `id` int(11) NOT NULL,
  `rate_id` int(11) NOT NULL DEFAULT '0',
  `product_id` varchar(1255) NOT NULL DEFAULT '',
  `point` int(11) NOT NULL DEFAULT '0',
  `ip_address` varchar(255) NOT NULL DEFAULT '',
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE `user_types` (
  `id` int(11) NOT NULL,
  `type_name` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`id`, `type_name`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_imported_users`
-- (See below for the actual view)
--
CREATE TABLE `v_imported_users` (
`UserID` int(11)
,`Name` varchar(250)
,`Surname` varchar(255)
,`UserName` varchar(150)
,`Password` varchar(150)
,`email` varchar(150)
);

-- --------------------------------------------------------

--
-- Structure for view `v_imported_users`
--
DROP TABLE IF EXISTS `v_imported_users`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_imported_users`  AS  select `imported_users`.`id` AS `UserID`,`imported_users`.`name` AS `Name`,`imported_users`.`surname` AS `Surname`,`imported_users`.`user_name` AS `UserName`,`imported_users`.`password` AS `Password`,`imported_users`.`email` AS `email` from `imported_users` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assignment_users`
--
ALTER TABLE `assignment_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignment_id` (`assignment_id`);

--
-- Indexes for table `cats`
--
ALTER TABLE `cats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `imported_users`
--
ALTER TABLE `imported_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_orders`
--
ALTER TABLE `payment_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `txn_id` (`txn_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `question_groups`
--
ALTER TABLE `question_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `question_types`
--
ALTER TABLE `question_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating_temps`
--
ALTER TABLE `rating_temps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles_rights`
--
ALTER TABLE `roles_rights`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `USR_LOGIN_INDEX` (`UserName`),
  ADD UNIQUE KEY `USR_EMAIL_INDEX` (`email`);

--
-- Indexes for table `user_answers`
--
ALTER TABLE `user_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_answers_ibfk_1` (`user_quiz_id`);

--
-- Indexes for table `user_quizzes`
--
ALTER TABLE `user_quizzes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignment_id` (`assignment_id`);

--
-- Indexes for table `user_ratings`
--
ALTER TABLE `user_ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_ratings_ibfk_1` (`rate_id`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `assignment_users`
--
ALTER TABLE `assignment_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cats`
--
ALTER TABLE `cats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `imported_users`
--
ALTER TABLE `imported_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000001;

--
-- AUTO_INCREMENT for table `payment_orders`
--
ALTER TABLE `payment_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `question_groups`
--
ALTER TABLE `question_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `rating_temps`
--
ALTER TABLE `rating_temps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `roles_rights`
--
ALTER TABLE `roles_rights`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50012;

--
-- AUTO_INCREMENT for table `user_answers`
--
ALTER TABLE `user_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=338;

--
-- AUTO_INCREMENT for table `user_quizzes`
--
ALTER TABLE `user_quizzes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_ratings`
--
ALTER TABLE `user_ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `question_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `assignment_users`
--
ALTER TABLE `assignment_users`
  ADD CONSTRAINT `assignment_users_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `question_groups`
--
ALTER TABLE `question_groups`
  ADD CONSTRAINT `question_groups_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_quizzes`
--
ALTER TABLE `user_quizzes`
  ADD CONSTRAINT `user_quizzes_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_ratings`
--
ALTER TABLE `user_ratings`
  ADD CONSTRAINT `user_ratings_ibfk_1` FOREIGN KEY (`rate_id`) REFERENCES `ratings` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
